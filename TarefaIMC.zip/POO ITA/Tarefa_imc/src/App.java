public class App {
    public static void main(String[] args) throws Exception {

        Paciente a = new Paciente("Lucas", 25, 70.5, 1.75);
        Paciente b = new Paciente("Manoela", 18, 76.8, 1.70);
        Paciente c = new Paciente("Claudio", 35, 112, 1.85);

        System.out.println("Resultados do paciente a:");
        System.out.println("IMC: " + a.calcularIMC());
        System.out.println("Status de Saúde: " + a.diagnostico());

        System.out.println("\nResultados do paciente b:");
        System.out.println("IMC: " + b.calcularIMC());
        System.out.println("Status de Saúde: " + b.diagnostico());

        System.out.println("\nResultados do paciente c:");
        System.out.println("IMC: " + c.calcularIMC());
        System.out.println("Status de Saúde: " + c.diagnostico());
    }
}
