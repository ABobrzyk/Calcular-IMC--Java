public class Paciente {

    private String nome;
    private int idade;
    private double peso;
    private double altura;

    public Paciente(String nome, int idade, double peso, double altura) {
        this.nome = nome;
        this.idade = idade;
        this.peso = peso;
        this.altura = altura;
    }

    // metodo calcular imc
    public double calcularIMC() {
        // IMC = peso (quilos) / (altura * altura (metros))
        return peso / (altura * altura);
    }

    public String diagnostico() {
        double imc = calcularIMC();
        if (imc < 16) {
            return "Abaixo do peso";
        } else if (imc >= 16 && imc <= 16.99) {
            return "Baixo peso grave";
        } else if (imc >= 17 && imc <= 18.49) {
            return "Baixo peso"; // IMC entre 17 e 18,49 kg/m²
        } else if (imc >= 18.50 && imc <= 24.99) { // IMC entre 18,50 e 24,99 kg/m²
            return "Peso normal";
        } else if (imc >= 25 && imc <= 29.99) {
            return "Sobrepeso";
        } else if (imc >= 30 && imc <= 34.99) {
            return "Obesidade grau 1";
        } else if (imc >= 35 && imc <= 39.99) {
            return "Obesidade grau 2";
        } else {
            return "Obesidade mórbida";
        }
    }
}
